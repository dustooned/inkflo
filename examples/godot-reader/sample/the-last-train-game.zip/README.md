# The Last Train — game package

Made with inkflo. Format `inkflo-game` version 1.

## Files

- `manifest.json`: pages, panels and balloons in **pixels** (origin top-left, y down).
  `norm` gives the same shapes as 0–1 fractions of the page.
- `pages/NNN/art.png`: the page without lettering. Show dialogue in your own UI over it.
- `pages/NNN/lettering.png`: balloons and captions alone, on transparent.
- `pages/NNN/page.png`: the finished page.
- `pages/NNN/panel-NN.png`: each panel cut to its shape (transparent outside), sized to the panel's `box`.
- `dialogue.yarn`: the script for Yarn Spinner; tags give the panel and the kind of line.
- `dialogue.ink`: the script for Ink; tags give the panel and the kind of line.

Panels are listed in reading order (left to right). Use `panels[i].box`
or `centre` to frame a camera, `lines` for the script of each panel, and `balloons` to place your
own speech bubbles (`box`, `tails` point at the speaker).

## Unity (C#)

```csharp
// Install com.unity.nuget.newtonsoft-json, put the package in StreamingAssets/comic
var json = File.ReadAllText(Path.Combine(Application.streamingAssetsPath, "comic/manifest.json"));
var comic = JObject.Parse(json);
foreach (var page in comic["pages"])
  foreach (var panel in page["panels"]) {
    var box = panel["box"];            // x, y, width, height in pixels
    var file = (string)panel["image"]; // pages/001/panel-01.png
    // Load the PNG as a Texture2D, make a Sprite, and move a Camera to frame box
  }
```

## Godot 4 (GDScript)

```gdscript
var comic = JSON.parse_string(FileAccess.get_file_as_string("res://comic/manifest.json"))
for page in comic.pages:
    for panel in page.panels:
        var tex = load("res://comic/" + panel.image)
        var box = panel.box  # x, y, width, height in pixels
        # Show tex in a Sprite2D at Vector2(box.x, box.y), or tween a Camera2D to the panel centre
        for line in panel.lines:
            print(line.speaker, ": ", line.text)
```

## Unreal

Import `manifest.json` with the JSON Blueprint Utilities plugin (or a DataTable from a
struct matching `panels`), load the panel PNGs as textures, and drive a Level Sequence camera
through `box` in order.
